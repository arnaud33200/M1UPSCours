
import question1.impl.ImplIdentifiable1;
import compDefQ1.Identification;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
