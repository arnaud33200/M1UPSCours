package question1;

public interface Identifiable {
	public String getIdentifiant();
}
