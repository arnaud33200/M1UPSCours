package question2;

public interface AnnounceInit {
	public void startProcessFor (String subject);
}
