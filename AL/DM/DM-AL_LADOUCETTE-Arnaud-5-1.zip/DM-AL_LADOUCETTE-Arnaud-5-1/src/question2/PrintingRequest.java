package question2;

public interface PrintingRequest {
	public void requestToPrint(String info);
}
