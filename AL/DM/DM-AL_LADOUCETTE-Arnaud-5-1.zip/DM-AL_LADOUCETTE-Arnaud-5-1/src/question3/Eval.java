package question3;

public interface Eval {
	public void start();
}
