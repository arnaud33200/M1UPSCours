package question3;

public interface EvalRequest {
	public double eval();
}
