package question3;

public interface ValidateRequest {
	public double evalAndValidate();
}
