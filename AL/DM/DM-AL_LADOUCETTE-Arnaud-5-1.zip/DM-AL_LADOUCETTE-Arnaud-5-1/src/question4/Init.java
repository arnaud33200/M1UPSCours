package question4;

public interface Init {
	public void startInitStep();
}
