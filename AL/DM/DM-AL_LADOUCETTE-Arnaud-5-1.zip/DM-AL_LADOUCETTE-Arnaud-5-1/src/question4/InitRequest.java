package question4;

public interface InitRequest {
	public String getIdForNewEval();
}
