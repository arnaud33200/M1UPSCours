package question5;

public interface ComputableEval {
	public double eval (String subject);
}
