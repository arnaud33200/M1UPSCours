package question5;

public interface StorableEval {
	public void store (String name, double value);
}
